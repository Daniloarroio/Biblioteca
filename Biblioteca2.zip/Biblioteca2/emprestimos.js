function toggleMenu(){
    let menu = document.getElementById("menuOpcoes");
    menu.style.display = (menu.style.display === "block") ? "none" : "block";
}

function home(){ window.location.href = "home.html"; }
function meusLivros(){ window.location.href = "livros.html"; }
function emprestimos(){ window.location.href ="emprestimos.html"; }

function logout(){
    localStorage.removeItem("logado"); 
    window.location.href = "login.html";
}

async function carregarEmprestimos(){

    const resposta = await fetch("http://localhost:8080/emprestimos");
    const emprestimos = await resposta.json();

    const lista = document.getElementById("listaEmprestimos");
    lista.innerHTML = "";

    emprestimos.forEach(emp => {

        const template = document.getElementById("emprestimoTemplate");
        const clone = template.content.cloneNode(true);

        clone.querySelector(".cliente").innerText = "";

        clone.querySelector(".livro").innerText = "Livro: " + emp.livro;
        clone.querySelector(".data").innerText = "Retirada: " + new Date(emp.dataEmprestimo).toLocaleDateString();
        clone.querySelector(".devolucao").innerText = "Devolução: " + new Date(emp.dataDevolucao).toLocaleDateString();

        const multa = emp.multa || 0;
        clone.querySelector(".multa").innerText = "Multa: R$ " + multa;

        clone.querySelector(".btn-encerrar").onclick = () => {
            encerrarEmprestimo(emp.id, multa);
        };

        lista.appendChild(clone);
    });
}

async function encerrarEmprestimo(id, multa){

    if(!confirm("Encerrar empréstimo?")) return;

    alert("Multa: R$ " + multa);

    await fetch(`http://localhost:8080/emprestimos/${id}`, {
        method: "DELETE"
    });

    carregarEmprestimos();
}

window.onload = carregarEmprestimos;