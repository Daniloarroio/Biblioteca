function toggleMenu(){
    let menu = document.getElementById("menuOpcoes");
    menu.style.display = (menu.style.display === "block") ? "none" : "block";
}

function CadastroClientes(){ window.location.href = "CadastroClientes.html"; }
function meusLivros(){ window.location.href= "livros.html"; }
function emprestimos(){ window.location.href ="emprestimos.html"; }

function logout(){
    localStorage.removeItem("logado");
    window.location.href = "login.html";
}

document.getElementById("pesquisa").addEventListener("input", async function(){

    let valor = this.value.toLowerCase();

    const resposta = await fetch("http://localhost:8080/livros");
    const livros = await resposta.json();

    const filtrados = livros.filter(livro =>
        livro.nome.toLowerCase().includes(valor)
    );

    mostrarLivros(filtrados);
});

function mostrarLivros(livros){

    const lista = document.getElementById("listaLivros");
    lista.innerHTML = "";

    livros.forEach(livro => {

        const template = document.getElementById("livroTemplate");
        const clone = template.content.cloneNode(true);

        clone.querySelector(".nome").value = livro.nome;
        clone.querySelector(".genero").value = livro.genero;

        clone.querySelector(".btn-excluir").onclick = () => {
            excluirLivro(livro.id);
        };

        lista.appendChild(clone);
    });
}

async function carregarLivros(){

    const resposta = await fetch("http://localhost:8080/livros");
    const livros = await resposta.json();

    mostrarLivros(livros);
}

async function cadastrarLivro(){

    let nome = document.getElementById("nomeLivro").value;
    let genero = document.getElementById("generoLivro").value;

    if(nome === "" || genero === ""){
        alert("Preencha todos os campos!");
        return;
    }

    try {

        const resposta = await fetch("http://localhost:8080/livros", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ nome, genero })
        });

        const texto = await resposta.text();
        alert(texto);

        document.getElementById("nomeLivro").value = "";
        document.getElementById("generoLivro").value = "";

        carregarLivros();

    } catch (erro) {
        alert("Erro ao cadastrar livro");
    }
}

async function excluirLivro(id){

    if(!confirm("Deseja excluir?")) return;

    await fetch(`http://localhost:8080/livros/${id}`, {
        method: "DELETE"
    });

    carregarLivros();
}

window.onload = function(){

    const logado = localStorage.getItem("logado");

    if(logado !== "true"){
        window.location.href = "login.html";
        return;
    }

    carregarLivros();
}