function toggleMenu(){
    let menu = document.getElementById("menuOpcoes");
    menu.style.display = (menu.style.display === "block") ? "none" : "block";
}

function home(){ window.location.href = "home.html"; }
function meusLivros(){ window.location.href = "livros.html"; }
function emprestimos(){ window.location.href ="emprestimos.html"; }
function logout(){ window.location.href = "login.html"; }


async function adicionarCliente(){

    let nome = document.getElementById("nome").value;
    let email = document.getElementById("email").value;
    let telefone = document.getElementById("telefone").value;
    let cpf = document.getElementById("cpf").value;

    const cliente = { nome, email, telefone, cpf };

    try {

        await fetch("http://localhost:8080/clientes", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(cliente)
        });

        alert("Cliente cadastrado!");

        limparCampos();
        carregarClientes();

    } catch (erro) {
        console.error(erro);
    }
}


async function carregarClientes() {

    const resposta = await fetch("http://localhost:8080/clientes");
    const clientes = await resposta.json();

    const lista = document.getElementById("listaClientes");
    lista.innerHTML = "";

    clientes.forEach(cliente => {

        const template = document.getElementById("clienteTemplate");
        const clone = template.content.cloneNode(true);

        clone.querySelector(".nome").value = cliente.nome;
        clone.querySelector(".email").value = cliente.email;
        clone.querySelector(".telefone").value = cliente.telefone;
        clone.querySelector(".cpf").value = cliente.cpf;

        clone.querySelector(".btn-excluir").onclick = () => {
            excluirCliente(cliente.id);
        };

        lista.appendChild(clone);
    });
}


async function excluirCliente(id){

    if(!confirm("Deseja excluir?")) return;

    await fetch(`http://localhost:8080/clientes/${id}`, {
        method: "DELETE"
    });

    carregarClientes();
}

function limparCampos(){
    document.getElementById("nome").value = "";
    document.getElementById("email").value = "";
    document.getElementById("telefone").value = "";
    document.getElementById("cpf").value = "";
}

window.onload = carregarClientes;