function toggleMenu(){
    let menu = document.getElementById("menuOpcoes");
    menu.style.display = (menu.style.display === "block") ? "none" : "block";
}

function home(){ window.location.href = "home.html"; }
function CadastroClientes(){ window.location.href = "CadastroClientes.html"; }
function emprestimos(){ window.location.href ="emprestimos.html"; }
function logout(){ window.location.href = "login.html"; }


async function buscarCliente(){

    let cpf = document.getElementById("cpf").value;

    if(cpf === ""){
        alert("Digite o CPF");
        return;
    }

    try {

        const resposta = await fetch("http://localhost:8080/clientes");
        const clientes = await resposta.json();

        const cliente = clientes.find(c => c.cpf === cpf);

        let div = document.getElementById("dadosCliente");

        if(cliente){
            div.innerHTML = `
                <p><strong>Nome:</strong> ${cliente.nome}</p>
                <p><strong>Email:</strong> ${cliente.email}</p>
            `;
        } else {
            div.innerHTML = "Cliente não encontrado!";
        }

    } catch (erro) {
        console.error(erro);
        alert("Erro ao buscar cliente");
    }
}


function definirDataHoje(){
    let hoje = new Date().toISOString().split("T")[0];
    document.getElementById("dataHoje").value = hoje;
}


async function registrarEmprestimo(){

    let cpf = document.getElementById("cpf").value;
    let livro = document.getElementById("livro").value;
    let dataDevolucao = document.getElementById("dataDevolucao").value;

    if(cpf === "" || livro === "" || dataDevolucao === ""){
        alert("Preencha todos os campos!");
        return;
    }

    try {

        const resposta = await fetch("http://localhost:8080/emprestimos", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                clienteId: cpf, 
                livro: livro,
                dataDevolucao: dataDevolucao
            })
        });

        const texto = await resposta.text();

        alert(texto);

        document.getElementById("livro").value = "";
        document.getElementById("dataDevolucao").value = "";

    } catch (erro) {
        console.error(erro);
        alert("Erro ao registrar empréstimo");
    }
}
window.onload = function(){

    if(document.getElementById("dataHoje")){
        definirDataHoje();
    }
};