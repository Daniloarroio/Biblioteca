function login(){

    let user = document.getElementById("usuario").value;
    let senha = document.getElementById("senha").value;

    const usuarioCorreto = "admin";
    const senhaCorreta = "1234";

    if(user === usuarioCorreto && senha === senhaCorreta){

        localStorage.setItem("logado", "true");

        alert("Login realizado com sucesso!");
        window.location.href = "home.html";

    } else {
        alert("Usuário ou senha inválidos!");
    }
}