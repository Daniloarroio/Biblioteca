package com.example.demo.controller;

import com.example.demo.model.Livro;
import com.example.demo.repository.LivroRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/livros")
public class LivroController {

    private final LivroRepository repo;

    public LivroController(LivroRepository repo){
        this.repo = repo;
    }

    @GetMapping
    public List<Livro> listar(){
        return repo.findAll();
    }

    @PostMapping
    public String salvar(@RequestBody Livro livro){

        if(livro.getNome() == null || livro.getGenero() == null){
            return "Preencha todos os campos";
        }

        repo.save(livro);
        return "Livro cadastrado!";
    }

    @DeleteMapping("/{id}")
    public String deletar(@PathVariable String id){
        repo.deleteById(id);
        return "Livro deletado";
    }
}
