package com.example.demo.controller;

import com.example.demo.model.Cliente;
import com.example.demo.repository.ClienteRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/clientes")
public class ClienteController {

    private final ClienteRepository repo;

    public ClienteController(ClienteRepository repo){
        this.repo = repo;
    }

    @GetMapping
    public List<Cliente> listar(){
        return repo.findAll();
    }

    @PostMapping
    public String salvar(@RequestBody Cliente cliente){
        repo.save(cliente);
        return "Cliente salvo!";
    }

    @DeleteMapping("/{id}")
    public String deletar(@PathVariable String id){
        repo.deleteById(id);
        return "Cliente deletado";
    }
}