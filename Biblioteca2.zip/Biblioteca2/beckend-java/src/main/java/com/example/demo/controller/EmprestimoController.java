package com.example.demo.controller;

import com.example.demo.model.Cliente;
import com.example.demo.model.Emprestimo;
import com.example.demo.repository.ClienteRepository;
import com.example.demo.repository.EmprestimoRepository;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/emprestimos")
public class EmprestimoController {

    private final EmprestimoRepository emprestimoRepo;
    private final ClienteRepository clienteRepo;

    public EmprestimoController(EmprestimoRepository e, ClienteRepository c){
        this.emprestimoRepo = e;
        this.clienteRepo = c;
    }

 @GetMapping
public List<Emprestimo> listar(){

    List<Emprestimo> lista = emprestimoRepo.findAll();

    Date hoje = new Date();

    for(Emprestimo e : lista){

        if(e.getDataDevolucao() != null && hoje.after(e.getDataDevolucao())){

            long diff = hoje.getTime() - e.getDataDevolucao().getTime();

            long dias = diff / (1000 * 60 * 60 * 24);

            double multa = dias * 10;
            
            e.setMulta(multa);

        }else {
                e.setMulta(0);
            }
    }

    return lista;
}

    @PostMapping
    public String criar(@RequestBody Emprestimo req){

        Cliente cliente = clienteRepo.findByCpf(req.getClienteId());

        if(cliente == null){
            return "Cliente não encontrado";
        }

        Date hoje = new Date();

        if(req.getDataDevolucao().before(hoje)){
            return "Data de devolução inválida";
        }

        req.setDataEmprestimo(new Date());
        req.setClienteId(cliente.getId());

        emprestimoRepo.save(req);

        return "Empréstimo realizado!";
    }

    @DeleteMapping("/{id}")
    public String deletar(@PathVariable String id){
        emprestimoRepo.deleteById(id);
        return "Empréstimo encerrado";
    }
}