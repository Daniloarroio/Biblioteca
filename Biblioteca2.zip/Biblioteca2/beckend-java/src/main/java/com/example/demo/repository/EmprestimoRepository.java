package com.example.demo.repository;

import com.example.demo.model.Emprestimo;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface EmprestimoRepository extends MongoRepository<Emprestimo, String> {
}